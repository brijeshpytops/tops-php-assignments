<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class EmployeeController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function __construct()
    {
        $this->middleware('check.employee')->only('show');
    }

    public function index()
    {
        return response()->json(['message' => 'Displaying all employees']);
    }

    public function show($id)
    {
        return response()->json(['message' => "Displaying employee with id: {$id}"]);
    }
}
