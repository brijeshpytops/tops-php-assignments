<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>web</title>
</head>
<body>
    This is a secreat web page
</body>
</html><?php /**PATH C:\xampp\htdocs\php-practice\create_custom_middleware\resources\views/web.blade.php ENDPATH**/ ?>